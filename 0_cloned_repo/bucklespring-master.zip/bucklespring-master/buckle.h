#ifndef buckle_h
#define buckle_h

int play(int code, int press);
int scan(int verbose);
void printd(const char *fmt, ...);
void open_console(void);

#endif

